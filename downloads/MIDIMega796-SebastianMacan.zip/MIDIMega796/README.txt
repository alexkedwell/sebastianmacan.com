SEBASTIAN MACAN - MIDI MEGA BUNDLE
Every MIDI pack in the store. 796 chord progressions.
Genre packs: Hit Chords 220, Club Chords 120, Soul Chords 120.
Mode packs: Ionian, Dorian, Phrygian, Lydian, Mixolydian, Aeolian, Locrian (48 each).
Drag any .mid into your DAW. Use in your music, commercial included. Do not resell the files themselves.
(c) 2026 Aluetion, LLC.
