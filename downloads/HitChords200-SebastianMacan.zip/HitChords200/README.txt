HIT CHORDS 200+ — Sebastian Macan
==================================

220 chord progressions from the harmonic DNA of decades of hit songs,
organized by genre. Every file is a standard MIDI file — drag and drop
straight into any DAW (Ableton, FL, Logic, Pro Tools, Reason, anything).

FOLDERS
  Pop                20 progressions
  HipHop_Trap        20
  RnB_Soul           20
  EDM_Dance          20
  Lofi_Chill         20
  Rock_Indie         20
  Latin_Afro         20
  Cinematic_Ambient  20
  Country_Folk       20
  Gospel_Jazz        20
  KPop_HyperPop      20

HOW TO USE
  1. Drag a .mid file onto an instrument track.
  2. Chords land one per bar at 90 BPM — change your project tempo freely,
     the chords follow.
  3. Transpose to your key, chop, re-voice, humanize. They are starting
     points — make them yours.

NOTES
  - Voicings include genre-appropriate extensions (7ths, 9ths, 13ths) plus
    a root bass note an octave down.
  - Chord progressions are not copyrightable; these are the common harmonic
    skeletons behind popular music, named for the vibe they carry.

FREE — from sebastianmacan.com
More free plugins: Chaos, Dusty, Ghost, Sugar, Bounce + new drops.

(c) 2026 Sebastian Macan. Pack may be used in commercial productions.
Redistribution/resale of the pack itself is not permitted.
