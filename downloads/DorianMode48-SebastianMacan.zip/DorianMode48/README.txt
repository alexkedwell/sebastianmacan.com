SEBASTIAN MACAN - Dorian MODE PACK
48 chord progressions in the Dorian mode. 4 keys x 12 progressions.
Every chord is diatonic to the mode, with the mode's signature color chord featured.
Drag any .mid straight into your DAW and play it with any sound.
One chord per bar at 90 BPM (tempo follows your project when dragged in).
(c) 2026 Aluetion, LLC. License: use in your music, commercial included. Do not resell the MIDI files themselves.
