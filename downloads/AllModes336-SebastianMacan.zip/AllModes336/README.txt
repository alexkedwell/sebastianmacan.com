SEBASTIAN MACAN - THE MODES BUNDLE
All 7 modes. 336 progressions. Ionian, Dorian, Phrygian, Lydian, Mixolydian, Aeolian, Locrian.
The complete modal songwriting toolkit. Nobody else makes this.
(c) 2026 Aluetion, LLC.
